create function numeric_pl_pg_lsn(numeric, pg_lsn) returns pg_lsn
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function numeric_pl_pg_lsn(numeric, pg_lsn) owner to amigoscode;

