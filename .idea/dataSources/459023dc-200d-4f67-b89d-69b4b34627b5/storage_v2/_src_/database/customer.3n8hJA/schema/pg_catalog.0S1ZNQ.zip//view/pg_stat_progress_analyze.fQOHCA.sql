create view pg_stat_progress_analyze
            (pid, datid, datname, relid, phase, sample_blks_total, sample_blks_scanned, ext_stats_total, ext_stats_computed, child_tables_total,
             child_tables_done, current_child_table_relid)
as
SELECT s.pid,
       s.datid,
       d.datname,
       s.relid,
       CASE s.param1
           WHEN 0 THEN 'initializing'::text
           WHEN 1 THEN 'acquiring sample rows'::text
           WHEN 2 THEN 'acquiring inherited sample rows'::text
           WHEN 3 THEN 'computing statistics'::text
           WHEN 4 THEN 'computing extended statistics'::text
           WHEN 5 THEN 'finalizing analyze'::text
           ELSE NULL::text
           END       AS phase,
       s.param2      AS sample_blks_total,
       s.param3      AS sample_blks_scanned,
       s.param4      AS ext_stats_total,
       s.param5      AS ext_stats_computed,
       s.param6      AS child_tables_total,
       s.param7      AS child_tables_done,
       s.param8::oid AS current_child_table_relid
FROM pg_stat_get_progress_info('ANALYZE'::text) s(pid, datid, relid, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10,
                                                  param11, param12, param13, param14, param15, param16, param17, param18, param19, param20)
         LEFT JOIN pg_database d ON s.datid = d.oid;

alter table pg_stat_progress_analyze
    owner to amigoscode;

grant select on pg_stat_progress_analyze to public;

